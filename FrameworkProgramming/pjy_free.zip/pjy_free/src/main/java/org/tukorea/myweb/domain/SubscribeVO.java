package org.tukorea.myweb.domain;

public class SubscribeVO {
	private String subId;
	private String subName;
	private String subPrice;
	private String subLevel;
	private String subLink;
	
	public String getSubId() {
		return subId;
	}
	public void setSubId(String subId) {
		this.subId = subId;
	}
	public String getSubName() {
		return subName;
	}
	public void setSubName(String subName) {
		this.subName = subName;
	}
	public String getSubPrice() {
		return subPrice;
	}
	public void setSubPrice(String subPrice) {
		this.subPrice = subPrice;
	}
	public String getSubLevel() {
		return subLevel;
	}
	public void setSubLevel(String subLevel) {
		this.subLevel = subLevel;
	}
	public String getSubLink() {
		return subLink;
	}
	public void setSubLink(String subLink) {
		this.subLink = subLink;
	}
}
